# http://upload.wikimedia.org/wikipedia/en/1/15/Xterm_256color_chart.svg
